<?php
require_once 'config/init.php';
require_once 'config/db.php';
require_once 'includes/archive_helpers.php';
require_once 'includes/auth_helpers.php';
require_once 'includes/homeowner_helpers.php';

if (empty($_SESSION['user_id'])) {
    header('Location: ' . BASE_PATH . '/login.php');
    exit;
}

$isAdmin = ($_SESSION['role'] ?? '') === 'admin';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!validateCsrfToken($_POST['csrf_token'] ?? '')) {
        $_SESSION['settings_error'] = 'Your session expired. Please try again.';
    } elseif (($_POST['action'] ?? '') === 'update_dues' && $isAdmin) {
        $dues = $_POST['dues'] ?? null;
        if (!is_array($dues) || !$dues) {
            $_SESSION['settings_error'] = 'No dues adjustments were submitted.';
        } else {
            $updatedCount = 0;
            $transactionStarted = false;
            try {
                $conn->begin_transaction();
                $transactionStarted = true;
                $stmt = $conn->prepare('UPDATE homeowners SET monthly_due = ? WHERE id = ?');
                if (!$stmt) {
                    throw new RuntimeException('Unable to prepare dues update.');
                }
                foreach ($dues as $homeownerId => $amount) {
                    if (!ctype_digit((string) $homeownerId) || !is_numeric($amount) || !is_finite((float) $amount) || (float) $amount < 0) {
                        throw new InvalidArgumentException('Please enter valid, non-negative dues for every homeowner.');
                    }
                    $homeownerId = (int) $homeownerId;
                    $amount = (float) $amount;
                    $stmt->bind_param('di', $amount, $homeownerId);
                    if (!$stmt->execute()) {
                        throw new RuntimeException('Unable to save all dues adjustments.');
                    }
                    $updatedCount += $stmt->affected_rows >= 0 ? 1 : 0;
                }
                $stmt->close();
                $conn->commit();
                $transactionStarted = false;
                $_SESSION['settings_success'] = "Updated dues for {$updatedCount} homeowner(s).";
            } catch (Throwable $e) {
                if ($transactionStarted) {
                    $conn->rollback();
                }
                if ($e instanceof InvalidArgumentException) {
                    $_SESSION['settings_error'] = $e->getMessage();
                } else {
                    error_log('Admin dues update failed for user ' . (int) $_SESSION['user_id'] . ': ' . $e->getMessage());
                    $_SESSION['settings_error'] = 'We could not save the dues adjustments. No changes were kept.';
                }
            }
        }
        $duesReturnParams = ['section' => 'dues'];
        $filterSearch = trim((string) ($_POST['filter_search'] ?? ''));
        $filterStreet = trim((string) ($_POST['filter_street'] ?? ''));
        if ($filterSearch !== '') $duesReturnParams['search'] = $filterSearch;
        if ($filterStreet !== '') $duesReturnParams['street'] = $filterStreet;
        header('Location: ' . BASE_PATH . '/settings.php?' . http_build_query($duesReturnParams));
        exit;
    } elseif (($_POST['action'] ?? '') === 'change_password') {
        $uid = (int) $_SESSION['user_id'];
        $current = (string) ($_POST['current_password'] ?? '');
        $new = (string) ($_POST['new_password'] ?? '');
        $confirm = (string) ($_POST['confirm_password'] ?? '');

        $check = reauth_check($conn, $uid, $current);
        if ($check !== true) {
            $_SESSION['settings_error'] = $check === 'Incorrect password.'
                ? 'Your current password is incorrect.'
                : $check;
        } elseif (strlen($new) < 8) {
            $_SESSION['settings_error'] = 'New password must be at least 8 characters.';
        } elseif ($new !== $confirm) {
            $_SESSION['settings_error'] = 'New passwords do not match.';
        } elseif ($new === $current) {
            $_SESSION['settings_error'] = 'New password must be different from your current password.';
        } else {
            try {
                $conn->begin_transaction();
                $hash = password_hash($new, PASSWORD_DEFAULT);
                $stmt = $conn->prepare('UPDATE users SET password = ? WHERE id = ?');
                if (!$stmt) {
                    throw new RuntimeException('Unable to prepare password update.');
                }
                $stmt->bind_param('si', $hash, $uid);
                if (!$stmt->execute()) {
                    throw new RuntimeException('Unable to update password.');
                }
                $stmt->close();

                $stmt = $conn->prepare('DELETE FROM password_resets WHERE user_id = ?');
                if (!$stmt) {
                    throw new RuntimeException('Unable to invalidate password reset links.');
                }
                $stmt->bind_param('i', $uid);
                if (!$stmt->execute()) {
                    throw new RuntimeException('Unable to invalidate password reset links.');
                }
                $stmt->close();
                $conn->commit();

                session_regenerate_id(true);
                $_SESSION['settings_success'] = 'Your password was updated.';
            } catch (Throwable $e) {
                $conn->rollback();
                error_log('Settings password update failed for user ' . $uid . ': ' . $e->getMessage());
                $_SESSION['settings_error'] = 'We could not update your password. Please try again.';
            }
        }
    } else {
        $_SESSION['settings_error'] = 'Invalid settings action.';
    }

    header('Location: ' . BASE_PATH . '/settings.php');
    exit;
}

$success = $_SESSION['settings_success'] ?? '';
$error = $_SESSION['settings_error'] ?? '';
unset($_SESSION['settings_success'], $_SESSION['settings_error']);
$csrfToken = generateCsrfToken();
$roleLabel = $isAdmin ? 'Administrator' : 'Resident';
$search = trim((string) ($_GET['search'] ?? ''));
$streets = ['Duhat', 'Santol', 'Mansanas', 'Granada', 'Guyabano', 'Atis', 'Ubas'];
$street = trim((string) ($_GET['street'] ?? ''));
if (!in_array(strtolower($street), array_map('strtolower', $streets), true)) $street = '';
$homeowners = [];
$duesLoadError = '';
if ($isAdmin) {
    try {
        ensure_archive_columns($conn, 'homeowners');
        $conditions = ['archived_at IS NULL'];
        $params = [];
        $types = '';
        if ($search !== '') {
            $conditions[] = '(block LIKE ? OR lot LIKE ? OR full_name LIKE ?)';
            $term = '%' . $search . '%';
            array_push($params, $term, $term, $term);
            $types .= 'sss';
        }
        if ($street !== '') {
            $conditions[] = 'LOWER(TRIM(block)) = LOWER(?)';
            $params[] = $street;
            $types .= 's';
        }
        $stmt = $conn->prepare('SELECT id, block, lot, full_name, status, monthly_due FROM homeowners WHERE ' . implode(' AND ', $conditions) . ' ORDER BY block, lot');
        if (!$stmt) throw new RuntimeException('Unable to prepare homeowner search.');
        if ($types !== '') $stmt->bind_param($types, ...$params);
        if (!$stmt->execute()) throw new RuntimeException('Unable to search homeowner records.');
        $result = $stmt->get_result();
        $homeowners = $result->fetch_all(MYSQLI_ASSOC);
        $stmt->close();
    } catch (Throwable $e) {
        error_log('Unable to load homeowner dues in Settings: ' . $e->getMessage());
        $duesLoadError = 'We could not load homeowner dues. Please try again later.';
    }
}

if ($isAdmin && ($_GET['ajax'] ?? '') === 'dues') {
    header('Content-Type: application/json; charset=utf-8');
    header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
    echo json_encode([
        'success' => $duesLoadError === '',
        'message' => $duesLoadError,
        'homeowners' => array_map(static function ($homeowner) {
            return [
                'id' => (int) $homeowner['id'],
                'block' => (string) ($homeowner['block'] ?? ''),
                'lot' => (string) ($homeowner['lot'] ?? ''),
                'address' => homeowner_address_label($homeowner['block'] ?? '', $homeowner['lot'] ?? ''),
                'full_name' => (string) ($homeowner['full_name'] ?? ''),
                'status' => (string) ($homeowner['status'] ?? 'inactive'),
                'monthly_due' => (string) ($homeowner['monthly_due'] ?? '0.00'),
            ];
        }, $homeowners),
    ], JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_AMP | JSON_HEX_QUOT);
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Settings - Manuela 4B MIS</title>
    <link rel="icon" type="image/png" href="Assets/css/images/logo2.png">
    <script>
    (function () {
        try {
            var d = document.documentElement;
            if (localStorage.getItem('sb_collapsed') === '1') d.classList.add('sb-collapsed');
        } catch (e) {}
    })();
    </script>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
    <link href="Assets/css/global.css?v=21" rel="stylesheet">
    <link href="Assets/css/components.css?v=22" rel="stylesheet">
    <link href="Assets/css/resident.css?v=23" rel="stylesheet">
    <link href="Assets/css/admin.css?v=27" rel="stylesheet">
    <link href="Assets/css/reference-theme.css?v=25" rel="stylesheet">
    <link href="Assets/css/ui-refresh.css?v=1" rel="stylesheet">
</head>
<body>
    <div class="app-wrapper">
        <?php require 'includes/sidebar.php'; ?>
        <main class="main-content settings-page">
            <div class="container-fluid p-0">
                <div class="page-header">
                    <div>
                        <h1>Settings</h1>
                        <p><?= $isAdmin ? 'Manage your account security and homeowner dues.' : 'Manage your account security.' ?></p>
                    </div>
                </div>

                <?php if ($success): ?>
                    <div class="alert alert-success d-flex align-items-center mb-4">
                        <i class="bi bi-check-circle-fill me-2"></i>
                        <div><?= htmlspecialchars($success, ENT_QUOTES, 'UTF-8') ?></div>
                    </div>
                <?php endif; ?>
                <?php if ($error): ?>
                    <div class="alert alert-danger d-flex align-items-center mb-4">
                        <i class="bi bi-exclamation-circle-fill me-2"></i>
                        <div><?= htmlspecialchars($error, ENT_QUOTES, 'UTF-8') ?></div>
                    </div>
                <?php endif; ?>

                <div class="card mb-4" style="max-width: 720px;">
                    <div class="card-body">
                        <div class="d-flex align-items-start gap-3 mb-4">
                            <div class="icon-box-soft icon-box-soft-primary">
                                <i class="bi bi-shield-lock"></i>
                            </div>
                            <div>
                                <h2 class="h5 fw-bold mb-1">Change Password</h2>
                                <p class="text-muted mb-0">Confirm your current password before setting a new one.</p>
                            </div>
                        </div>

                        <form method="POST" autocomplete="off">
                            <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrfToken, ENT_QUOTES, 'UTF-8') ?>">
                            <input type="hidden" name="action" value="change_password">
                            <div class="mb-3">
                                <label for="currentPassword" class="form-label">Current Password</label>
                            <div class="password-visibility-field password-visibility-field--inline">
                                <input type="password" id="currentPassword" name="current_password" class="form-control" autocomplete="current-password" required>
                                <button type="button" class="password-visibility-toggle password-visibility-toggle--icon" data-password-target="currentPassword" data-password-label="current password" aria-label="Show current password" aria-pressed="false"><i class="bi bi-eye-fill" aria-hidden="true"></i></button>
                                </div>
                            </div>
                            <div class="mb-3">
                                <label for="newPassword" class="form-label">New Password</label>
                                <div class="password-visibility-field password-visibility-field--inline">
                                    <input type="password" id="newPassword" name="new_password" class="form-control" minlength="8" autocomplete="new-password" required>
                                    <button type="button" class="password-visibility-toggle password-visibility-toggle--icon" data-password-target="newPassword" data-password-label="new password" aria-label="Show new password" aria-pressed="false"><i class="bi bi-eye-fill" aria-hidden="true"></i></button>
                                </div>
                                <div class="form-text">Use at least 8 characters.</div>
                            </div>
                            <div class="mb-4">
                                <label for="confirmPassword" class="form-label">Confirm New Password</label>
                                <div class="password-visibility-field password-visibility-field--inline">
                                    <input type="password" id="confirmPassword" name="confirm_password" class="form-control" minlength="8" autocomplete="new-password" required>
                                    <button type="button" class="password-visibility-toggle password-visibility-toggle--icon" data-password-target="confirmPassword" data-password-label="confirmation password" aria-label="Show confirmation password" aria-pressed="false"><i class="bi bi-eye-fill" aria-hidden="true"></i></button>
                                </div>
                            </div>
                            <button type="submit" class="btn btn-primary">
                                <i class="bi bi-key me-1"></i> Update Password
                            </button>
                        </form>
                    </div>
                </div>

                <?php if ($isAdmin): ?>
                    <section class="card mt-4">
                        <div class="card-body">
                            <div class="d-flex align-items-start gap-3 mb-4">
                                <div class="icon-box-soft icon-box-soft-warning">
                                    <i class="bi bi-cash-stack"></i>
                                </div>
                                <div>
                                    <h2 class="h5 fw-bold mb-1">Manage Homeowner Dues</h2>
                                    <p class="text-muted mb-0">Adjust each homeowner's monthly due. Changes apply to future billing.</p>
                                </div>
                            </div>

                            <?php if ($duesLoadError): ?>
                                <div class="alert alert-danger"><?= htmlspecialchars($duesLoadError, ENT_QUOTES, 'UTF-8') ?></div>
                            <?php endif; ?>

                            <form method="GET" action="<?= BASE_PATH ?>/settings.php" class="row g-3 align-items-end mb-2" id="duesFilterForm">
                                <input type="hidden" name="section" value="dues">
                                <div class="col-12 col-md-8">
                                    <label for="duesSearch" class="form-label">Find a homeowner</label>
                                    <div class="cir-search">
                                        <i class="bi bi-search cir-search__icon" aria-hidden="true"></i>
                                        <input type="search" id="duesSearch" name="search" class="cir-search__field"
                                               placeholder="Search house number or name"
                                               value="<?= htmlspecialchars($search, ENT_QUOTES, 'UTF-8') ?>" autocomplete="off">
                                        <span class="cir-search__kbd" aria-hidden="true">Enter</span>
                                    </div>
                                </div>
                                <div class="col-12 col-md-4">
                                    <label for="duesStreet" class="form-label">Street</label>
                                    <select id="duesStreet" name="street" class="form-select">
                                        <option value="">All streets</option>
                                        <?php foreach ($streets as $streetOption): ?>
                                            <option value="<?= htmlspecialchars($streetOption, ENT_QUOTES, 'UTF-8') ?>" <?= strcasecmp($street, $streetOption) === 0 ? 'selected' : '' ?>><?= htmlspecialchars($streetOption, ENT_QUOTES, 'UTF-8') ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                            </form>
                            <div id="duesResultsStatus" class="small text-muted mb-3" role="status" aria-live="polite">
                                Showing <?= count($homeowners) ?> homeowner<?= count($homeowners) === 1 ? '' : 's' ?>. Results update as you type or change street.
                            </div>

                            <form method="POST">
                                <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrfToken, ENT_QUOTES, 'UTF-8') ?>">
                                <input type="hidden" name="action" value="update_dues">
                                <input type="hidden" name="filter_search" value="<?= htmlspecialchars($search, ENT_QUOTES, 'UTF-8') ?>">
                                <input type="hidden" name="filter_street" value="<?= htmlspecialchars($street, ENT_QUOTES, 'UTF-8') ?>">
                                <div class="table-responsive">
                                    <table class="table table-hover align-middle mb-0">
                                        <thead>
                                            <tr>
                                                <th>Property Address</th>
                                                <th>Homeowner</th>
                                                <th>Status</th>
                                                <th style="min-width: 190px;">Monthly Due (₱)</th>
                                            </tr>
                                        </thead>
                                        <tbody id="duesRows">
                                            <?php foreach ($homeowners as $homeowner): ?>
                                                <?php
                                                    $status = strtolower((string) ($homeowner['status'] ?? 'inactive'));
                                                    $badgeClass = $status === 'active' ? 'text-bg-success' : ($status === 'pending' ? 'text-bg-warning' : 'text-bg-secondary');
                                                ?>
                                                <tr>
                                                    <td><?= htmlspecialchars(homeowner_address_label($homeowner['block'] ?? '', $homeowner['lot'] ?? ''), ENT_QUOTES, 'UTF-8') ?></td>
                                                    <td><?= htmlspecialchars((string) ($homeowner['full_name'] ?? ''), ENT_QUOTES, 'UTF-8') ?></td>
                                                    <td><span class="badge <?= $badgeClass ?>"><?= htmlspecialchars(ucfirst($status), ENT_QUOTES, 'UTF-8') ?></span></td>
                                                    <td>
                                                        <div class="input-group">
                                                            <span class="input-group-text">₱</span>
                                                            <input type="number" min="0" step="0.01"
                                                                   name="dues[<?= (int) $homeowner['id'] ?>]"
                                                                   class="form-control"
                                                                   value="<?= htmlspecialchars((string) ($homeowner['monthly_due'] ?? '0.00'), ENT_QUOTES, 'UTF-8') ?>"
                                                                   required>
                                                        </div>
                                                    </td>
                                                </tr>
                                            <?php endforeach; ?>
                                            <?php if (!$homeowners): ?>
                                                <tr>
                                                <td colspan="4" class="text-center text-muted py-4">
                                                        <?= ($search !== '' || $street !== '') ? 'No homeowners match your selected filters.' : 'No homeowner records found.' ?>
                                                    </td>
                                                </tr>
                                            <?php endif; ?>
                                        </tbody>
                                    </table>
                                </div>
                                <div id="duesSaveActions" class="d-flex justify-content-end mt-4" <?= $homeowners ? '' : 'hidden' ?>>
                                    <button type="submit" class="btn btn-primary">
                                        <i class="bi bi-check2-circle me-1"></i> Save Dues
                                    </button>
                                </div>
                            </form>
                        </div>
                    </section>
                <?php endif; ?>
            </div>
        </main>
    </div>
    <script>
    (function () {
        var filterForm = document.getElementById('duesFilterForm');
        var searchInput = document.getElementById('duesSearch');
        var streetSelect = document.getElementById('duesStreet');
        var rows = document.getElementById('duesRows');
        var status = document.getElementById('duesResultsStatus');
        var saveActions = document.getElementById('duesSaveActions');
        var duesForm = document.querySelector('input[name="action"][value="update_dues"]')?.form;
        if (!filterForm || !searchInput || !streetSelect || !rows || !status) return;

        var timer = null;
        var requestNumber = 0;
        var dirtyDues = new Map();

        function addCell(row, value) {
            var cell = document.createElement('td');
            cell.textContent = value;
            row.appendChild(cell);
            return cell;
        }

        function rememberDues() {
            rows.querySelectorAll('input[name^="dues["]').forEach(function (input) {
                if (input.dataset.edited === '1') {
                    var match = input.name.match(/^dues\[(\d+)\]$/);
                    if (match) dirtyDues.set(match[1], input.value);
                }
            });
        }

        function renderHomeowners(homeowners, search, street) {
            rows.replaceChildren();
            if (saveActions) saveActions.hidden = !homeowners.length;
            if (!homeowners.length) {
                var emptyRow = document.createElement('tr');
                var emptyCell = addCell(emptyRow, search || street ? 'No homeowners match your selected filters.' : 'No homeowner records found.');
                emptyCell.colSpan = 4;
                emptyCell.className = 'text-center text-muted py-4';
                rows.appendChild(emptyRow);
                return;
            }

            homeowners.forEach(function (homeowner) {
                var row = document.createElement('tr');
                addCell(row, homeowner.address);
                addCell(row, homeowner.full_name);
                var statusCell = document.createElement('td');
                var badge = document.createElement('span');
                var homeownerStatus = (homeowner.status || 'inactive').toLowerCase();
                badge.className = 'badge ' + (homeownerStatus === 'active' ? 'text-bg-success' : (homeownerStatus === 'pending' ? 'text-bg-warning' : 'text-bg-secondary'));
                badge.textContent = homeownerStatus.charAt(0).toUpperCase() + homeownerStatus.slice(1);
                statusCell.appendChild(badge);
                row.appendChild(statusCell);

                var dueCell = document.createElement('td');
                var group = document.createElement('div');
                group.className = 'input-group';
                var currency = document.createElement('span');
                currency.className = 'input-group-text';
                currency.textContent = '₱';
                var dueInput = document.createElement('input');
                dueInput.type = 'number';
                dueInput.min = '0';
                dueInput.step = '0.01';
                dueInput.name = 'dues[' + homeowner.id + ']';
                dueInput.className = 'form-control';
                dueInput.value = dirtyDues.has(String(homeowner.id)) ? dirtyDues.get(String(homeowner.id)) : homeowner.monthly_due;
                dueInput.required = true;
                dueInput.addEventListener('input', function () {
                    dueInput.dataset.edited = '1';
                    dirtyDues.set(String(homeowner.id), dueInput.value);
                });
                group.append(currency, dueInput);
                dueCell.appendChild(group);
                row.appendChild(dueCell);
                rows.appendChild(row);
            });
        }

        function updateResults() {
            rememberDues();
            var thisRequest = ++requestNumber;
            var search = searchInput.value.trim();
            var street = streetSelect.value;
            var url = new URL(filterForm.action, window.location.href);
            url.searchParams.set('section', 'dues');
            url.searchParams.set('ajax', 'dues');
            if (search) url.searchParams.set('search', search); else url.searchParams.delete('search');
            if (street) url.searchParams.set('street', street); else url.searchParams.delete('street');

            status.textContent = 'Updating homeowner list…';
            filterForm.setAttribute('aria-busy', 'true');
            fetch(url.toString(), { credentials: 'same-origin', cache: 'no-store', headers: { 'Accept': 'application/json' } })
                .then(function (response) {
                    if (!response.ok) throw new Error('Could not update homeowner list.');
                    return response.json();
                })
                .then(function (data) {
                    if (thisRequest !== requestNumber) return;
                    if (!data.success) throw new Error(data.message || 'Could not update homeowner list.');
                    var homeowners = Array.isArray(data.homeowners) ? data.homeowners : [];
                    renderHomeowners(homeowners, search, street);
                    if (duesForm) {
                        var filterSearch = duesForm.querySelector('input[name="filter_search"]');
                        var filterStreet = duesForm.querySelector('input[name="filter_street"]');
                        if (filterSearch) filterSearch.value = search;
                        if (filterStreet) filterStreet.value = street;
                    }
                    status.textContent = 'Showing ' + homeowners.length + ' homeowner' + (homeowners.length === 1 ? '' : 's') + '. Results update as you type or change street.';
                    url.searchParams.delete('ajax');
                    window.history.replaceState({}, '', url.toString());
                })
                .catch(function (error) {
                    if (thisRequest !== requestNumber) return;
                    status.textContent = error.message || 'Could not update homeowner list. Please try again.';
                })
                .finally(function () {
                    if (thisRequest === requestNumber) filterForm.removeAttribute('aria-busy');
                });
        }

        filterForm.addEventListener('submit', function (event) {
            event.preventDefault();
            window.clearTimeout(timer);
            updateResults();
        });
        searchInput.addEventListener('input', function () {
            window.clearTimeout(timer);
            timer = window.setTimeout(updateResults, 300);
        });
        streetSelect.addEventListener('change', function () {
            window.clearTimeout(timer);
            updateResults();
        });

        if (duesForm) duesForm.addEventListener('submit', function () {
            rememberDues();
            var visibleIds = new Set(Array.from(rows.querySelectorAll('input[name^="dues["]')).map(function (input) {
                var match = input.name.match(/^dues\[(\d+)\]$/);
                return match ? match[1] : '';
            }));
            dirtyDues.forEach(function (value, id) {
                if (visibleIds.has(id)) return;
                var hidden = document.createElement('input');
                hidden.type = 'hidden';
                hidden.name = 'dues[' + id + ']';
                hidden.value = value;
                hidden.dataset.filteredDues = '1';
                duesForm.appendChild(hidden);
            });
        });
    })();
    </script>
    <?php require_once 'includes/footer.php'; ?>
</body>
</html>
